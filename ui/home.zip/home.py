import streamlit as st
import pandas as pd
import psycopg2
import os
from datetime import datetime
import json

# Database connection to external Neon database
DB_URI = "postgresql://neondb_owner:npg_o6AY4XRynVZK@ep-wandering-grass-a1ha7u59-pooler.ap-southeast-1.aws.neon.tech/neondb?sslmode=require"


def get_db_connection():
    """Get database connection to external Neon database"""
    try:
        return psycopg2.connect(DB_URI)
    except Exception as e:
        st.error(f"Database connection error: {e}")
        return None

# This function is used in multiple places, so we define it once here.
def parse_hashtags(value):
    """Parses hashtag strings from various formats (JSON, PSQL array) into a list."""
    if isinstance(value, (list, tuple)):
        return list(value)
    if isinstance(value, str):
        try:
            # Attempt to parse as JSON array, e.g., '["tag1", "tag2"]'
            parsed = json.loads(value)
            if isinstance(parsed, list):
                return parsed
        except json.JSONDecodeError:
            # Handle PostgreSQL array string format, e.g., '{tag1,tag2}'
            if value.startswith('{') and value.endswith('}'):
                tags = value.strip('{}').split(',')
                # Clean up each tag (remove quotes and whitespace)
                return [tag.strip().strip('"') for tag in tags if tag.strip()]
    # For None, non-string types, or parsing failures, return an empty list
    return []


@st.cache_data(ttl=3600)
def fetch_news(lang,
               limit=10,
               offset=0,
               sort_by='date_desc',
               search_query='',
               _force_refresh=False):
    """
    Fetches news from the PostgreSQL database, selecting content based on the chosen language.
    Supports pagination, sorting, and keyword search.
    """
    conn = get_db_connection()
    if not conn:
        return pd.DataFrame()

    try:
        cursor = conn.cursor()

        # Define columns based on the selected language
        title_col = f'title_{lang}'
        summary_col = f'summary_{lang}'
        hashtags_col = f'hashtags_{lang}'
        # Use content_raw for Thai, otherwise use the translated content
        content_col = 'content_raw' if lang == 'th' else f'content_translated_{lang}'

        # Base query selects only the necessary columns for the current language
        query = f"""
            SELECT 
                id, 
                source, 
                url, 
                date, 
                language,
                {title_col} AS title,
                {summary_col} AS summary,
                {hashtags_col} AS hashtags,
                {content_col} AS content
            FROM epidemic_news
        """
        params = []
        where_clauses = []

        if search_query:
            # Search across the language-specific columns
            where_clauses.append(
                f"({title_col} ILIKE %s OR {summary_col} ILIKE %s OR {hashtags_col}::text ILIKE %s)"
            )
            params.extend([f"%{search_query}%", f"%{search_query}%", f"%{search_query}%"])

        if where_clauses:
            query += " WHERE " + " AND ".join(where_clauses)

        # Add sorting
        order_map = {
            'date_desc': 'date DESC',
            'date_asc': 'date ASC',
            'title_asc': 'title ASC',
            'title_desc': 'title DESC'
        }
        query += f" ORDER BY {order_map.get(sort_by, 'date DESC')}"

        # Add pagination
        query += " LIMIT %s OFFSET %s;"
        params.extend([limit, offset])

        cursor.execute(query, tuple(params))
        rows = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]
        df = pd.DataFrame(rows, columns=columns)

        if 'hashtags' in df.columns:
            # Apply parse_hashtags to the 'hashtags' column
            df['hashtags'] = df['hashtags'].apply(parse_hashtags)
        
        return df

    except Exception as e:
        st.error(f"Error fetching news: {e}")
        return pd.DataFrame()
    finally:
        if conn:
            cursor.close()
            conn.close()


def get_total_news_count(lang, search_query=''):
    """Fetches the total count of news articles for pagination based on language."""
    conn = get_db_connection()
    if not conn:
        return 0

    try:
        cursor = conn.cursor()
        title_col = f'title_{lang}'
        summary_col = f'summary_{lang}'
        hashtags_col = f'hashtags_{lang}'

        query = "SELECT COUNT(*) FROM epidemic_news"
        params = []
        if search_query:
            query += f" WHERE ({title_col} ILIKE %s OR {summary_col} ILIKE %s OR {hashtags_col}::text ILIKE %s)"
            params.extend([f"%{search_query}%", f"%{search_query}%", f"%{search_query}%"])

        cursor.execute(query, tuple(params))
        count = cursor.fetchone()[0]
        return count
    except Exception as e:
        st.error(f"Error fetching total news count: {e}")
        return 0
    finally:
        if conn:
            cursor.close()
            conn.close()


def display_news_detail(container, news_item, lang):
    """Displays the full details of a single news item based on language."""
    container.markdown(f"## {news_item.get('title', 'ไม่มีหัวข้อ')}")

    if container.button({"th": "⬅️ กลับไปที่ข่าว", "en": "⬅️ Back to News", "ko": "⬅️ 뉴스 목록으로", "jp": "⬅️ ニュースに戻る"}[lang], key="back_to_news_list"):
        st.session_state.view_news_id = None
        st.rerun()

    display_date = news_item['date'].strftime("%Y-%m-%d %H:%M") if isinstance(news_item['date'], datetime) else str(news_item['date'])
    container.markdown(
        f"<p style='font-size: 0.95em; color: #555; opacity: 0.8;'>📅 {display_date} | 📰 {news_item['source']} | 🌐 {news_item['language'].upper()}</p>",
        unsafe_allow_html=True
    )

    if news_item.get('url'):
        link_text = {"th": "เปิดลิงก์ข่าวต้นฉบับ", "en": "Open Original News Link", "ko": "원본 뉴스 링크 열기", "jp": "元のニュースลิงก์を開く"}[lang]
        container.markdown(
            f"<p><a href='{news_item['url']}' target='_blank' style='color: #007bff; text-decoration: none; font-weight: bold;'>🔗 {link_text}</a></p>",
            unsafe_allow_html=True
        )

    # Display full content
    content_text = {"th": "เนื้อหาข่าว", "en": "News Content", "ko": "뉴스 내용", "jp": "뉴스 내용"}[lang]
    container.markdown(f"### {content_text}")
    container.markdown(f"<p>{news_item.get('content', 'Content not available.')}</p>", unsafe_allow_html=True)

    # The "Related Hashtags" section has been removed/commented out from here.

def show():
    """Display the home page with news feed."""
    lang = st.session_state.get('language', 'th')

    if 'view_news_id' not in st.session_state:
        st.session_state.view_news_id = None
    if 'current_page' not in st.session_state:
        st.session_state.current_page = 1
    if 'items_per_page' not in st.session_state:
        # Get default from settings if available, otherwise use 10
        st.session_state.items_per_page = st.session_state.get('items_per_page', 10)
    if 'sort_order' not in st.session_state:
        st.session_state.sort_order = 'date_desc'
    if 'search_query' not in st.session_state:
        st.session_state.search_query = ''

    st.title({"th": "หน้าแรก - ข่าวโรคระบาด", "en": "Home - Epidemic News", "ko": "홈 - 전염병 뉴스", "jp": "ホーム - 感染症ニュース"}[lang])

    if st.session_state.view_news_id:
        conn = get_db_connection()
        if conn:
            try:
                cursor = conn.cursor()
                # Select all columns to ensure we get language-specific titles/summaries/content
                cursor.execute("SELECT * FROM epidemic_news WHERE id = %s", (st.session_state.view_news_id,))
                rows = cursor.fetchall()
                columns = [desc[0] for desc in cursor.description]
                if rows:
                    news_df_detail = pd.DataFrame(rows, columns=columns)
                    news_item_detail = news_df_detail.iloc[0].to_dict()
                    
                    # Manually construct the news item for display based on the current language
                    lang_item = {
                        'id': news_item_detail['id'],
                        'source': news_item_detail['source'],
                        'url': news_item_detail['url'],
                        'date': news_item_detail['date'],
                        'language': news_item_detail['language'],
                        'title': news_item_detail.get(f'title_{lang}'),
                        'summary': news_item_detail.get(f'summary_{lang}'),
                        # Ensure parse_hashtags is applied to the correct language-specific column
                        'hashtags': parse_hashtags(news_item_detail.get(f'hashtags_{lang}')), 
                        'content': news_item_detail.get('content_raw') if lang == 'th' else news_item_detail.get(f'content_translated_{lang}')
                    }
                    display_news_detail(st, lang_item, lang)
                    return
            except Exception as e:
                st.error(f"Error fetching news detail: {e}")
            finally:
                conn.close()

        st.session_state.view_news_id = None
        st.rerun()

    col1, col2, col3 = st.columns([3, 1, 1])
    with col1:
        search_query = st.text_input({"th": "🔍 ค้นหาข่าว", "en": "🔍 Search News", "ko": "🔍 뉴스 검색", "jp": "🔍 ニュース検索"}[lang], value=st.session_state.search_query, key="news_search")
    with col2:
        sort_order = st.selectbox({"th": "เรียงตาม", "en": "Sort by", "ko": "정렬", "jp": "並び順"}[lang], options=['date_desc', 'date_asc', 'title_asc', 'title_desc'], format_func=lambda x: {"date_desc": {"th": "วันที่ (ใหม่สุด)", "en": "Date (Newest)", "ko": "날짜 (최신)", "jp": "日付 (最新)"}[lang], "date_asc": {"th": "วันที่ (เก่าสุด)", "en": "Date (Oldest)", "ko": "날짜 (오래된)", "jp": "日付 (古い)"}[lang], "title_asc": {"th": "หัวข้อ (ก-ฮ)", "en": "Title (A-Z)", "ko": "제목 (가-하)", "jp": "タイトル (あ-ん)"}[lang], "title_desc": {"th": "หัวข้อ (ฮ-ก)", "en": "Title (Z-A)", "ko": "제목 (하-가)", "jp": "タイトル (ん-あ)"}[lang]}[x], index=0, key="news_sort")
    with col3:
        # Use st.session_state.items_per_page as the default for the selectbox
        items_per_page = st.selectbox(
            {"th": "แสดง", "en": "Show", "ko": "표시", "jp": "表示"}[lang],
            options=[10, 20, 50],
            index=[10, 20, 50].index(st.session_state.items_per_page) if st.session_state.items_per_page in [10, 20, 50] else 0,
            key="items_per_page_select"
        )

    if search_query != st.session_state.search_query or \
       sort_order != st.session_state.sort_order or \
       items_per_page != st.session_state.items_per_page: # Check for changes
        st.session_state.search_query = search_query
        st.session_state.sort_order = sort_order
        st.session_state.items_per_page = items_per_page # Update session state
        st.session_state.current_page = 1
        st.rerun()

    offset = (st.session_state.current_page - 1) * st.session_state.items_per_page
    news_df = fetch_news(lang=lang, limit=st.session_state.items_per_page, offset=offset, sort_by=st.session_state.sort_order, search_query=st.session_state.search_query)

    if news_df.empty:
        st.info({"th": "ไม่พบข่าวสาร", "en": "No news found", "ko": "뉴스를 찾을 수 없습니다", "jp": "ニュースが見つかりません"}[lang])
        return

    for idx, row in news_df.iterrows():
        with st.container(border=True):
            col1, col2 = st.columns([3, 1])
            with col1:
                title_text = row.get('title', 'ไม่มีหัวข้อ')
                st.markdown(f"### {title_text}")

                display_date = row['date'].strftime("%Y-%m-%d %H:%M") if isinstance(row['date'], datetime) else str(row['date'])
                st.markdown(
                    f"<p style='font-size: 0.9em; color: #666;'>📅 {display_date} | 📰 {row['source']} | 🌐 {row['language'].upper()}</p>",
                    unsafe_allow_html=True
                )
                
            
                summary_content = row.get("summary")
                if summary_content:
                    st.markdown(f"<p>{summary_content}</p>", unsafe_allow_html=True)

            with col2:
                st.markdown("<br>", unsafe_allow_html=True)
                if st.button({"th": "อ่านเพิ่มเติม", "en": "Read More", "ko": "더 보기", "jp": "続きを読む"}[lang], key=f"read_more_{row['id']}", use_container_width=True):
                    st.session_state.view_news_id = row['id']
                    st.rerun()

    total_count = get_total_news_count(lang, st.session_state.search_query)
    total_pages = (total_count + st.session_state.items_per_page - 1) // st.session_state.items_per_page

    if total_pages > 1:
        st.markdown("---")
        p_col1, p_col2, p_col3 = st.columns([1, 2, 1])

        prev_label = {"th": "ก่อนหน้า", "en": "Previous", "ko": "이전", "jp": "前へ"}[lang]
        next_label = {"th": "ถัดไป", "en": "Next", "ko": "다음", "jp": "次へ"}[lang]
        
        with p_col1:
            if st.button(f"⬅️ {prev_label}", disabled=st.session_state.current_page <= 1):
                st.session_state.current_page -= 1
                st.rerun()
        with p_col2:
            st.markdown(f"<div style='text-align: center; padding-top: 10px;'>{st.session_state.current_page} / {total_pages}</div>", unsafe_allow_html=True)
        with p_col3:
            if st.button(f"{next_label} ➡️", disabled=st.session_state.current_page >= total_pages):
                st.session_state.current_page += 1
                st.rerun()